
<form method="_POST" action={{route(" ")}}>

    <input type="text" name="title" placeholder="Enter Event Title">
    <input type="text" name="location" placeholder="Enter Location">
    <input type="text" name="purpose" placeholder="Enter type of event">
    <input type="submit" name="submit">








</form>




