<html>
<h1>
<p>{{$event[0]->Title}}</p>

</h1>
<a href="http://127.0.0.1:8888/meetup/public/home/join/{{$event[0]->id}}">Join this Event</a> <
</html>