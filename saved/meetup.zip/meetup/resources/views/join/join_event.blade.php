@extends('layouts.app')

@section('content')

    <h1>Title: {{$event_details[0]->Title}} </h1>
    <h1>Location:{{$event_details[0]->location}}</h1>
    <h1>Date:{{$event_details[0]->date}}</h1>
<?php // use Illuminate\Support\Facades\DB;
          $mail=Auth::user()->email;
        $event_id=$event_details[0]->id;
          $status = DB::table('emails')
                   ->where('email',$mail )
                    ->where('event_id', $event_id)->get();
           ?>

    <h1>Status: {{ $status[0]->status}} </h1>
    <form  method="post" action={{route("update")}}>

        @csrf
        <input type="hidden" name="update" value="accepeted"/>
        <input type="hidden" name="event_id" value={{$event_details[0]->id}} />
        <button type="submit">   Accept</button>


    </form>
    <form  method="post" action={{route("update")}}>

        @csrf
        <input type="hidden" name="update" value="rejected"/>
        <input type="hidden" name="event_id" value={{$event_details[0]->id}} />
        <button type="submit">   Reject</button>


    </form>
    <form  method="post" action={{route("update")}}>

        @csrf
        <input type="hidden" name="update" value="May be"/>
        <input type="hidden" name="event_id" value={{$event_details[0]->id}} />
        <button type="submit">   Maybe</button>


    </form>
@endsection


