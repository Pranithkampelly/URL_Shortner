@extends('layouts.app')

@section('content')

    <h1>Send invitations</h1>


    <form method="post" action={{route("event_update_mail")}}>

        @csrf
        <input type="hidden" name="event_id" value="{{$event_details[0]->id}}">


        <input type="text" name="mail" placeholder=" Send invitations " >

        <input type="submit" name="update">



    </form>
@endsection