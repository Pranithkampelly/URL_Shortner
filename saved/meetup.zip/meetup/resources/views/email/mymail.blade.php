<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MY mail</title>
</head>
<body>
<h1>You got an invitation for meetup</h1>

<br>
<h1>
<a href="http://127.0.0.1:8888/meetup/public/home/join/">CLICK HERE FOR ACCEPTING</a>
</h1>
</body>
</html>