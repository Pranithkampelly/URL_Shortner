<html>
<h1>
    <h2>Title: {{$event->Title}} </h2>
    <h2>Location:{{$event->location}}</h2>
    <h2>Date:{{$event->date}}</h2>


</h1>
<h1>
<a href="http://127.0.0.1:8888/meetup/public/home/myevents/{{$event->id}}">Update Event</a> <
</h1>
<h1>
    <a href="http://127.0.0.1:8888/meetup/public/home/myevents/mail/{{$event->id}}">Send Invitations</a> <
</h1>
<h2>................................................................................... </h2>
</html>
