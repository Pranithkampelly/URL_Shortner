@extends('layouts.app')

@section('content')

<h1>Event Details</h1>


<form method="post" action={{route("new")}}>

    @csrf

    <input type="text" name="title" placeholder="Enter Event Title">
    <input type="text" name="location" placeholder="Enter Location">
    <input type="text" name="purpose" placeholder="Enter type of event">
    <input type="date" name="date">
    <input type="text" name="mail" placeholder="Send invitations">
    <input type="submit" name="submit">





</form>
@endsection