@extends('layouts.app')

@section('content')

    <h1>Update Details</h1>


    <form method="post" action={{route("event_update")}}>

        @csrf
        <input type="hidden" name="event_id" value={{$event_details[0]->id}}">

        <input type="text" name="title" placeholder="{{$event_details[0]->Title}}">
        <input type="text" name="location" placeholder="{{$event_details[0]->location}}">
        <input type="text" name="purpose" placeholder="{{$event_details[0]->Purpose}}">
        <input type="date" name="date" >
        <input type="submit" name="update">





    </form>
@endsection