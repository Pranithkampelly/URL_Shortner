<?php


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\UserController;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

//


Route::get('/', function () {
    return view('welcome');
});

Auth::routes(['verify' => true]);


Route::get('/home', 'HomeController@index')->name('home');

Route::get('/join',function(){

    $user=User::find(1);
    return $user->events;
})->middleware('verified');


Route::get('home/create',['as'=>'users.create','uses'=>'HomeController@create'])->middleware('verified');
Route::post("meetup/public/home/create/new",['as'=>'new','uses'=>'HomeController@store']);
Route::get('home/join',['as'=>'users.join','uses'=>'HomeController@join'])->middleware('verified');

Route::get('home/myevents', function () {

 $id=Auth::user()->id;
  $user=User::find($id);
   $display= $user->events;
  //echo "Your Events:"."<br>"."<br>";
  foreach($display as $eventdisplay) {
      //  echo "Title: ".$eventdisplay->Title.'<br>'."Location: ".$eventdisplay->location."<br>"."<br>";}
     echo view('update')->with('event',$eventdisplay);

  }
})->middleware('verified');



Route::get('home/myevents/{id}', function ($id) {

    $event_details = DB::table('events')->where('id', $id)->get();
    return view('update_event',['event_details' =>  $event_details]);

})->middleware('verified');




Route::get('home/join/{id}', function ($id) {

    $event_details = DB::table('events')->where('id', $id)->get();
    return view('join/join_event',['event_details' =>  $event_details]);

})->middleware('verified');

Route::post("meetup/public/home/join/update",['as'=>'update','uses'=>'HomeController@update']);
Route::post("meetup/public/home/myevents/update",['as'=>'event_update','uses'=>'HomeController@update_event']);


Route::get('home/myevents/mail/{id}', function ($id) {

    $event_details = DB::table('events')->where('id', $id)->get();
    return view('update_event_mail',['event_details' =>  $event_details]);

})->middleware('verified');

Route::post("meetup/public/home/myevents/mail/update",['as'=>'event_update_mail','uses'=>'HomeController@update_event_mail']);

Route::get('home/joins/public',['as'=>'join_public','uses'=>'HomeController@join_public'])->middleware('verified');