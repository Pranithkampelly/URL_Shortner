<?php

namespace App\Http\Controllers;

use App\Event;
use App\Event_User;
use App\Mail\SendMail;
use App\User;
use Illuminate\Contracts\Mail\Mailer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
     public function create()
     {
         return view('event');
     }


    public function join()
    {
        $id=Auth::user()->id;
        $user=User::find($id);
        $user_email= $user->email;
        $user_events = DB::table('emails')->where('email', $user_email)->get();
        foreach($user_events as $event_details) {
            $event = DB::table('events')->where('id', $event_details->event_id)->get();

            echo view('join/join')->with('event',$event)."<br>";
        }


    }


    public function join_public()
    {

       return view('join.public');

    }

    public function update(){
        $mail=Auth::user()->email;
        $event_id= request('event_id');
        $update=request('update');
        DB::table('emails')
            ->where('email',$mail )->where('event_id', $event_id)
            ->update(['status' => $update]);
        return Redirect::back();
    }


    public function store(Mailer $mailer)
    {
        $event = new Event();

        $id=Auth::user()->id;
        $event_user_id= $id;

        $event->Organizer_id=$id;
        $event->Title= request('title');
        $event->location = request('location');
        $event->Purpose= request('purpose');
        $event->date=request('date');
        $event->save();


        $user_event_id=$event->id ;
        DB::insert('insert into event_user(event_id,user_id) values(?,?)',[$user_event_id,$event_user_id]);

        $string = request('mail');
        $str_arr = explode (",", $string);



           foreach ($str_arr as $arr) {
               DB::insert('insert into emails(event_id,email) values(?,?)', [$user_event_id, $arr]);
               $event_id=$user_event_id;
               $mailer->to($arr)->send(new SendMail($event_id));
           }


        return redirect('/home');

    }


    public function update_event(){

        $event_id= request('event_id');

        $id=Auth::user()->id;
        $event=DB::table('events')->find($event_id);
        DB::table('events')->where('Organizer_id', $id)->where('id', $event_id)->update(['Title' => request('title')]);
        DB::table('events')->where('Organizer_id', $id)->where('id', $event_id)->update(['location' => request('location')]);
        DB::table('events')->where('Organizer_id', $id)->where('id', $event_id)->update(['Purpose' => request('purpose')]);
        DB::table('events')->where('Organizer_id', $id)->where('id', $event_id)->update(['date' => request('date')]);
;
        return Redirect::back();
    }
    public function update_event_mail(Mailer $mailer){

        $event_id= request('event_id');

        $id=Auth::user()->id;
        $string = request('mail');
        $str_arr = explode (",", $string);



        foreach ($str_arr as $arr) {
            DB::insert('insert into emails(event_id,email) values(?,?)', [$event_id, $arr]);
            $mailer->to($arr)->send(new SendMail($event_id));
        }

        return Redirect::back();
    }



}
