<html>
<h1>
    <h2>Title: <?php echo e($event->Title); ?> </h2>
    <h2>Location:<?php echo e($event->location); ?></h2>
    <h2>Date:<?php echo e($event->date); ?></h2>


</h1>
<h1>
<a href="http://127.0.0.1:8888/meetup/public/home/myevents/<?php echo e($event->id); ?>">Update Event</a> <
</h1>
<h1>
    <a href="http://127.0.0.1:8888/meetup/public/home/myevents/mail/<?php echo e($event->id); ?>">Send Invitations</a> <
</h1>
<h2>................................................................................... </h2>
</html>
<?php /**PATH /Applications/MAMP/htdocs/meetup/resources/views/update.blade.php ENDPATH**/ ?>