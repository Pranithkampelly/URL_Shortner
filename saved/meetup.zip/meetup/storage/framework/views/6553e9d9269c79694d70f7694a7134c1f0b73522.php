<?php $__env->startSection('content'); ?>

<h1>Event Details</h1>


<form method="post" action=<?php echo e(route("new")); ?>>

    <?php echo csrf_field(); ?>

    <input type="text" name="title" placeholder="Enter Event Title">
    <input type="text" name="location" placeholder="Enter Location">
    <input type="text" name="purpose" placeholder="Enter type of event">
    <input type="date" name="date">
    <input type="text" name="mail" placeholder="Send invitations">
    <input type="submit" name="submit">





</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/meetup/resources/views/event.blade.php ENDPATH**/ ?>