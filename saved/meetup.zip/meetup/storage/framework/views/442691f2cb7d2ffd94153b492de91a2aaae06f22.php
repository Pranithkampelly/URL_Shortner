<?php $__env->startSection('content'); ?>

    <h1>Update Details</h1>


    <form method="post" action=<?php echo e(route("event_update")); ?>>

        <?php echo csrf_field(); ?>
        <input type="hidden" name="event_id" value=<?php echo e($event_details[0]->id); ?>">

        <input type="text" name="title" placeholder="<?php echo e($event_details[0]->Title); ?>">
        <input type="text" name="location" placeholder="<?php echo e($event_details[0]->location); ?>">
        <input type="text" name="purpose" placeholder="<?php echo e($event_details[0]->Purpose); ?>">
        <input type="date" name="date" >
        <input type="submit" name="update">





    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/meetup/resources/views/update_event.blade.php ENDPATH**/ ?>