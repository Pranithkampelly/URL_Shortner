<html>

<p><?php echo e($event[0]->Title); ?></p>
<a href="http://127.0.0.1:8888/meetup/public/home/join/<?php echo e($event[0]->id); ?>">Join this Event</a> <

</html><?php /**PATH /Applications/MAMP/htdocs/meetup/resources/views/join.blade.php ENDPATH**/ ?>