<?php echo e($slot); ?>

<?php /**PATH /Applications/MAMP/htdocs/meetup/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>